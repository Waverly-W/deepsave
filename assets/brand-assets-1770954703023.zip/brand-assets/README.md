# Brand Assets

该资产包由 AI 图稿工程化工具自动生成。

## 参数信息
- 主色: #31BA80
- 辅色: #1F8BA5
- 风格标签: minimal
- 输出场景: web

## 目录说明
- /logo: SVG 资源（light/dark/mono/logo-mark）
- /png: 多尺寸位图资源（logo/favicon/pwa）

## 文件清单
- logo/logo-primary-light.svg
- logo/logo-primary-dark.svg
- logo/logo-monochrome-black.svg
- logo/logo-monochrome-white.svg
- logo/logo-mark.svg
- png/logo-mark-1024.png
- png/logo-mark-512.png
- png/logo-mark-256.png
- png/favicon-48.png
- png/favicon-32.png
- png/favicon-16.png
- png/pwa-192.png
- png/pwa-512.png

## 使用建议
- Web 场景优先使用 SVG
- favicon 推荐使用 32px/16px
- PWA 图标使用 192/512